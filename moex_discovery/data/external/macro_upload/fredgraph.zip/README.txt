----------------------------------------------------------------
FRED Graph Observations
Federal Reserve Economic Data, Federal Reserve Bank of St. Louis
Link: https://fred.stlouisfed.org
Help: https://fredhelp.stlouisfed.org
This data may be copyrighted. Please refer to the Terms of Use:
https://fred.stlouisfed.org/legal#fred-terms-faq
File Created: 2026-02-05 11:56 pm CST
----------------------------------------------------------------

--------  ---------------------------------------------------------------------  ------------------------
DFF       Federal Funds Effective Rate, Percent, Daily, Not Seasonally Adjusted  Data Updated: 2026-02-05
DFEDTARU  Federal Funds Target Range - Upper Limit, Percent, Daily, Not          Data Updated: 2026-02-05
          Seasonally Adjusted
DFEDTARL  Federal Funds Target Range - Lower Limit, Percent, Daily, Not          Data Updated: 2026-02-05
          Seasonally Adjusted
SOFR      Secured Overnight Financing Rate, Percent, Daily, Not Seasonally       Data Updated: 2026-02-05
          Adjusted
IORB      Interest Rate on Reserve Balances (IORB Rate), Percent, Daily, Not     Data Updated: 2026-02-05
          Seasonally Adjusted
--------  ---------------------------------------------------------------------  ------------------------

